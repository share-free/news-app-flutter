class Constant{
  static String baseUrl ="https://newsapi.org/v2/";
  static String key = "4835b01aff0c40c286144c45865eb373";
}